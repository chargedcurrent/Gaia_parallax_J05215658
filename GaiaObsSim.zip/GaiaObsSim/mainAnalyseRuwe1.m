% Main program to analyse the sensitivity of the Gaia DR2 parallax and 
% proper motion estimates for J05215658 (Gaia DR2 207628584632757632) 
% to orbital motion.

% Test sensitivity of RUWE to orbital motion for different true parallaxes

% L. Lindegren 2018-11-16

% random number initialization for reproducibility:
seed = 1;
RandStream.setGlobalStream(RandStream('mt19937ar','Seed',1));

% general constants:
twopi = 2 * pi;
JD2000 = 2451545.0; % JD for J2000.0
tRef = 2015.5; % reference epoch for Gaia DR2
year = 365.25; % Julian year in days

% assumed period and observational errors:
P = 83.205 / year; % orbital period in years
sigma_obs = 0.28; % assumed sigma per CCD observation [mas]

% limits on cos(i)
%cosiLim = [-0.8,0.8];
cosiLim = [-1.0,1.0];

% time of maximum blueshift (e-mail Thompson 2018-10-13 kl. 15:35): 
t_recedingNode = 2000.0 + (2458110.0 - JD2000) / year;
M0_fixed = 4.01982647514223; % mean anomaly (+omega) at 2015.5

% Monte Carlo: generate nMC random orbits at each true parallax plx0:
plxList = [0.3; 0.4; 0.5; 0.6; 0.7; 0.8; 0.9; 1.0; 1.1; 1.2];
nPlx = length(plxList);
nMC = 10000;

% load Gaia DR2 data for J05215658 from Gaia Archive:
src = readTable('dr2.txt');
% note: src is structure containing the DR2 fields, e.g.
% src.source_id = 207628584632757632
% src.parallax = 0.271745260505027

% (edited) table from GOST (https://gaia.esac.esa.int/gost):
table = readTable('gost.txt'); % this reads the table to structure table
% note: table is a structure with the following fields: 
%                        colNames: {10×1 cell}
%                            nCol: 10
%                            file: 'gost.txt'
%                           types: [10×1 double]
%                            nRow: 26
%                              ra: [26×1 double]
%                             dec: [26×1 double]
%                          CcdRow: [26×1 double]
%                  zetaFieldAngle: [26×1 double]
%                       scanAngle: [26×1 double]
%         parallaxFactorAlongScan: [26×1 double]
%        parallaxFactorAcrossScan: [26×1 double]
%     ObservationTimeAtBarycentre: [26×1 double]

nTr = table.nRow; % number of tranits (predicted from GOST)
raRad = src.ra * pi / 180;
decRad = src.dec * pi / 180;

% scan geometry etc (these are vectors of length nTr):
s = sin(table.scanAngle);
c = cos(table.scanAngle);
pf = table.parallaxFactorAlongScan;
t = 2000.0 + (table.ObservationTimeAtBarycentre - JD2000) / year;
tau = t - tRef;
tau_recedingNode = t_recedingNode - tRef;

% multiply by 9 CCD strips:
s = [s; s; s; s; s; s; s; s; s];
c = [c; c; c; c; c; c; c; c; c];
pf = [pf; pf; pf; pf; pf; pf; pf; pf; pf];
tau = [tau; tau; tau; tau; tau; tau; tau; tau; tau];
nTr = length(s);

% design matrix (nTr rows, 5 columns for ra dec, plx, pmra, pmdec):
D = [ s, c, pf, s.*tau, c.*tau ];

sig0 = [src.ra_error; src.dec_error; src.parallax_error; ...
    src.pmra_error; src.pmdec_error];
sig0 = sig0 / mean(sig0);

corr0 = [src.ra_dec_corr; src.ra_parallax_corr; src.ra_pmra_corr; ...
    src.ra_pmdec_corr; src.dec_parallax_corr; src.dec_pmra_corr; ...
    src.dec_pmdec_corr; src.parallax_pmra_corr; src.parallax_pmdec_corr; ...
    src.pmra_pmdec_corr];

uwe = zeros(nMC,nPlx); % array to hold the UWE (including photon noise)
plx = zeros(nMC,nPlx); % array to hold the observed (biased, noisy) parallax

M0 = ones(nMC,1) * M0_fixed; % mean anomaly (+omega) at 2015.5
for iPlx = 1 : nPlx

    % cos(i) is uniform in [cosiLim(1), cosiLim(2)]:
    cosi = cosiLim(1) + rand(nMC,1)*(cosiLim(2)-cosiLim(1)); 
    sini = sqrt(1 - cosi.^2);
    
    plx0 = plxList(iPlx); % true parallax
    a = 0.341 * plx0 ./ sini; % true orbital semi-diameter 
    
    omega = 0; % periastron is at the receding node
    Omega = twopi * rand(nMC,1); % Omega is uniform in [0,2*pi]
    
    % Thiele-Innes constants (these are vectors of length nMC):
    A = a .* (cos(omega).*cos(Omega) - sin(omega).*sin(Omega).*cosi);
    B = a .* (cos(omega).*sin(Omega) + sin(omega).*cos(Omega).*cosi);
    F = a .* (-sin(omega).*cos(Omega) - cos(omega).*sin(Omega).*cosi);
    G = a .* (-sin(omega).*sin(Omega) + cos(omega).*cos(Omega).*cosi);
    
    % calculate UWE:
    for k = 1 : nMC
        % removed 21 observations randomly
        q = randperm(nTr, src.astrometric_n_good_obs_al);
        dof = length(q) - 5;
        M = M0(k) + (twopi/P) * tau(q);  % mean anomaly
        x = A(k) * cos(M) + F(k) * sin(M);  % displacement in RA
        y = B(k) * cos(M) + G(k) * sin(M);  % displacement in Dec
        d0 = x.*s(q) + y.*c(q); % noiseless obs
        d1 = d0 + randn(size(d0)) * sigma_obs; % noisy obs
        sol = D(q,:) \ d1; % LS solution of D * sol = d1
        res = (d1 - D(q,:) * sol) / sigma_obs;
        uwe(k,iPlx) = sqrt(res'*res / dof);
        plx(k,iPlx) = plx0 + sol(3);
    end
    hi = find(uwe(:,iPlx) > 1.055 & plx(:,iPlx) < 0.322);
    fprintf('true plx = %f: fraction UWE > 1.055: %g\n', plx0, length(hi)/nMC);
end

fid = fopen('simUwe.txt','w');
fprintf(fid,'iMC,p0_3,p0_4,p0_5,p0_6,p0_7,p0_8,p0_9,p1_0,p1_1,p1_2,uwe0_3,uwe0_4,uwe0_5,uwe0_6,uwe0_7,uwe0_8,uwe0_9,uwe1_0,uwe1_1,uwe1_2\n');
for k = 1 : nMC
    fprintf(fid,'%d,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f\n', ...
        k, plx(k,:), uwe(k,:));
end
fclose(fid);
