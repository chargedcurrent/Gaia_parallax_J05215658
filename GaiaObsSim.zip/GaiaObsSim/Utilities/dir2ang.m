function [ lonRad, latRad ] = dir2ang( r )
% converts (possibly non-unit) vector to (lon,lat) in [rad]
% L. Lindegren 2015-02-08

lonRad = atan2(r(2),r(1));
latRad = atan2(r(3),sqrt(r(1)^2+r(2)^2));

end

