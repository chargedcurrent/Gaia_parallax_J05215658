function [ S ] = readTable(file, silent)
% Read a table in ASCII or CSV format (silently, if silent = true).
% An ASCII table has at least one header line beginning with '#', with
% the last header line contains the column names
% A CSV table has only one header line (not beginning with '#'), and it
% contains the column names separated by commas.
% L. Lindegren 2017-02-28

% If the table contains long (64 bit) integers (NB: this is tested only 
% in the first data line!), then it needs at least MATLAB version 8.0 
% for reading them correctly (using %ld). That the version is at least 8.0
% is only checked when a column with long integers is detected. Also, a
% table already stored in the compact .mat form can be read with earlier
% MATLAB versions (at least R2009b), even if it contains long integers.

% If the text file has already been read and saved as a .mat file, then
% just load the .mat file to save time. But if the text file was modified 
% since the last save, it must be read again: 
verb = ~(nargin > 1 && silent == true);
saveName = strcat(file,'.mat');
changed = false;
if (exist(saveName,'file'))
    saved = true;  % .mat file exists; now check its currency:
    fileTxt = dir(file);
    if (exist(file,'file'))
        dateTxt = datevec(fileTxt.date);
        fileMat = dir(saveName);
        dateMat = datevec(fileMat.date);
        dt = etime(dateMat, dateTxt);
        changed = (dt < 0); % true if text file is newer than the .mat file
    else % if txt file does not exist, assume that mat file is current
    end
else
    saved = false; % no .mat file exists
end

if (saved && ~changed)
    if (verb)
        fprintf('Loading %s ... ', saveName);
    end
    tStart = tic;
    load(saveName,'S');
    dt = toc(tStart);
    if (verb)
        fprintf('done (%f seconds)\n', dt);
    end
    if (~isfield(S, 'file'))
        S.file = file;
    end
    return;
end

% The text file must be read:
if (verb)
    if (changed)
        fprintf('Saved .mat file is not up-to-date, creating a new one.\n');
    end
    fprintf('Reading %s ... ', file);
end
tStart = tic;
fid = fopen(file, 'r');

nh = 0;
line0 = fgetl(fid);
line1 = fgetl(fid);
ascii = strcmp(line0(1), '#');
csv = false;
hdr = cell(1,1);
nRow = 0;
if (ascii)
    % more header lines?
    while (strcmp(line1(1), '#'))
        nh = nh + 1;
        hdr{nh,1} = strtrim(line0(2:end));
        line0 = line1;
        line1 = fgetl(fid);
    end
    % at this point hdr contains header lines, line0 the column names, and
    % line1 the first data line
    cols = textscan(line0(2:end), '%s');
    dataLine = textscan(line1, '%s');
else % if the first non-white character in line0 is a letter, assume it is the header of a CSV file
    tmp = strip(line0);
    if (isletter(tmp(1:1)))
        cols = textscan(line0, '%s', 'delimiter', ',');
        dataLine = textscan(line1, '%s', 'delimiter', ',');
        csv = true;
    else
        dataLine = textscan(line0, '%s', 'delimiter', ',');
        nCol = length(dataLine{1});
        for iCol = 1 : nCol
            names{iCol} = sprintf('col%d', iCol);
        end
        cols{1} = names;
        nRow = 1;
    end
end
names = cols{1};
S.hdr = hdr;
S.nHdr = nh;
S.colNames = names;
S.nCol = length(names);
S.file = file;
if (ascii)
    S.fileType = 'ASCII';
elseif (csv)
    S.fileType = 'CSV';
else
    S.fileType = 'NONE';
end

% Use data (containing the first line of data) to determine data types:
data = dataLine{1};
if (length(data) ~= S.nCol)
    error('Length of first data record (%d) does not match the number of column headers (%d)', ...
        length(data), S.nCol);
end
types = zeros(S.nCol,1); % type = 0, 1, 2 for ASCII, int64, double
for j = 1 : S.nCol
    str = strtrim(data{j});
    if (strcmp(str,'NaN'))
        types(j) = 2;  % double
    else
        dbl = str2double(str);
        if (~isnan(dbl))  % numeric
            if (strfind(str, '.'))
                types(j) = 2;  % double
            elseif (abs(dbl) > 2.0^31)
                types(j) = 1;  % long integer if it is >31 bits
            else
                types(j) = 2;  % double
            end
        else
            types(j) = 0; % ASCII
        end
    end
end
S.types = types;

% If there are long integers, at least MATLAB 8.0 is needed to read them:
if (~isempty(find(types == 1, 1)))
    needsMatlabVersion(8.0);
end

% Count number of data records
while ischar(line1)
    nRow = nRow + 1;
    line1 = fgetl(fid);
end
fclose(fid);
S.nRow = nRow;

% Create a format specifier for the data lines:
format = [];
for j = 1 : S.nCol
    if (types(j) == 0)
        format = [format, '%s '];
    elseif (types(j) == 1)
        format = [format, '%d64 '];
    else
        format = [format, '%f '];
    end
end

% Open file again, skip N header records and read data:
fid = fopen(file, 'r');
if (ascii || csv)
    Nskip = S.nHdr + 1;
else
    Nskip = S.nHdr;
end
Nread = S.nRow;
if (ascii)
    data = textscan(fid, format, Nread, 'HeaderLines', Nskip);
else
    data = textscan(fid, format, Nread, 'HeaderLines', Nskip, ...
        'Delimiter', ',');
end
fclose(fid);

% Check that all rows have actually been read:
nRowRead = length(data{:,1});
if (nRowRead ~= S.nRow)
    error('Only %d of %d rows of data could be read - empty elements?',...
        nRowRead, S.nRow);
end

for j = 1 : S.nCol
    S.(names{j}) = data{:,j};
end

% Save for future reads, but only if the number of data items is < 100M
% (the exact limit has not been determined) - otherwise it needs the -v7.4
% option which takes exceedingly long time to store and much more space:
if (S.nRow*S.nCol < 2e8)
    save(saveName,'S');
end

dt = toc(tStart);
if (verb)
    fprintf('done (%f seconds)\n', dt);
    fprintf('-- found %d lines of data in %d columns.\n', S.nRow, S.nCol);
end
return
