function [ lonRadB, latRadB, mStarLonB, mLatB ] = transPosPm( ...
    lonRadA, latRadA, mStarLonA, mLatA, BA)
% General transformation of position (lonRad,latRad) [rad] and 
% proper motions (mStarLon,mLat) [arbitrary unit] from one
% reference frame A to another B (e.g. A = ICRS, B = Galactic) 
% using the transformation matrix BA = B'A.
% L. Lindegren 2014-04-14

% triad and proper motion vector in A:
[ pA, qA, rA ] = normalTriad( lonRadA, latRadA );
mA = pA * mStarLonA + qA * mLatA;

% triad and proper motion vector in B:
rB = BA * rA;
mB = BA * mA;

% convert to angles and proper motion components:
[ lonRadB, latRadB ] = dir2ang( rB );
[ pB, qB ] = normalTriad( lonRadB, latRadB );
mStarLonB = pB' * mB;
mLatB = qB' * mB;

end

