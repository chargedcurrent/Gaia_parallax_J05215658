function [ p, q, r ] = normalTriad( alpha, delta )
% for position (alpha,delta) [rad] returns three orthogonal unit vectors
% p, q, r with p along increasing alpha, q along increasing delta, and
% r towards (alpha,delta). [p,q,r] is the normal triad (VA 1983).
% L. Lindegren 2011-08-07

ca = cos(alpha);
sa = sin(alpha);
cd = cos(delta);
sd = sin(delta);

r = [ cd*ca ; cd*sa ; sd ];
p = [ -sa ; ca ; 0 ];
q = [ -sd*ca ; -sd*sa ; cd ];

end

