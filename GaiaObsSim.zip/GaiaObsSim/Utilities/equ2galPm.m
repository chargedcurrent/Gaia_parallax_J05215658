function [ lRad, bRad, ml, mb ] = equ2galPm( aRad, dRad, ma, md )
% converts alpha, delta [rad] to galactic l, b [rad]
% and also proper motions ma, md [arbitrary unit] to ml, mb
% L. Lindegren 2015-02-08

% matrix G'E from "Astrometry for Astrophysics" (van Altena, ed.), (4.27)
GE = [ -0.054875560416215, -0.873437090234885, -0.483835015548713; ...
       +0.494109427875584, -0.444829629960011, +0.746982244497219; ...
       -0.867666149019005, -0.198076373431202, +0.455983776175067 ];

[ lRad, bRad, ml, mb ] = transPosPm( aRad, dRad, ma, md, GE);

end

