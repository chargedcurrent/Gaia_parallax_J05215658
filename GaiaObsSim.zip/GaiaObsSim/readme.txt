Simulation of Gaia observations of J05215658

MATLAB scripes etc by L. Lindegren (Lund Observatory)


Input files:

- dr2.txt : Gaia DR2 data for the source
- gost.txt : edited output from GOST (predicted times etc of the Gaia observations)


Main programs:

- mainAnalyseSensitivity.m : MATLAB script to analyse the sensitivity of parallax
and proper motion to orbital motion by MC simulation. Generates a text (csv) file 
simPlxPmBiasRes_RV.txt with one line per MC experiment, and various plots of the 
biases and UWE. The diagrams in Fig. 5 is constructed from these data.

- mainAnalyseRuwe1.m : MATLAB script to simulate observed parallax and UWE for
a given true parallax. Output is simUwe.txt, with one line per MC experiment, 
containing the observed parallax and UWE for true parallax 0.3, 0.4, ..., 1.2 mas.
Fig. 6 was constructed from this table. 

- mainAnalyseRuwe2.m : MATLAB script to calculate the fraction of cases where
the observed parallax (and UWE) are below a certain value, as a function of
the true parallax and minimum value of sin(i). Two tables are generated,
simFrac0VsTruePlx.txt without an upper limit on UWE, and simFrac1VsTruePlx.txt 
with the additional constraint that UWE < 1.1. Fig. 7 is constructed from these.


Utilities:

This folder contains utility functions for general things like reading cvs files 
and coordinate transformation. It needs to be in the PATH for MATLAB.
