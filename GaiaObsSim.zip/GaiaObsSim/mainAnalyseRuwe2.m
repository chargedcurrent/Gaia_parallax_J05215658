% Main program to analyse the sensitivity of the Gaia DR2 parallax and 
% proper motion estimates for J05215658 (Gaia DR2 207628584632757632) 
% to orbital motion.

% Produce table of fractions plx<0.322 mas and plx<0.322 & uwe<1.1

% L. Lindegren 2018-11-26

clear all
clc
close all

% random number initialization for reproducibility:
seed = 1;
RandStream.setGlobalStream(RandStream('mt19937ar','Seed',1));

% general constants:
twopi = 2 * pi;
JD2000 = 2451545.0; % JD for J2000.0
tRef = 2015.5; % reference epoch for Gaia DR2
year = 365.25; % Julian year in days

% assumed period and observational errors:
P = 83.205 / year; % orbital period in years
sigma_obs = 0.28; % assumed sigma per CCD observation [mas]
sigma_sys = 0.043; % systematic uncertainty (mas)

% constraints:
plxObs = 0.322; % observed parallax (mas)
uweMax = 1.1; % upper limit on (R)UWE

% time of maximum blueshift (e-mail Thompson 2018-10-13 kl. 15:35): 
t_recedingNode = 2000.0 + (2458110.0 - JD2000) / year;
M0_fixed = 4.01982647514223; % mean anomaly (+omega) at 2015.5

% values of sin(i) considered:
siniMin = [0.0, 0.2, 0.4, 0.6, 0.8];  % lower limits for sin(i)
ns = length(siniMin);

% values of true parallax considered:
plxList = (0.3 : 0.05 : 1.2)';
np = length(plxList);

% number of MC experiments per plx/sini combination:
nMC = 10000; %1000000;

% load Gaia DR2 data for J05215658 from Gaia Archive:
src = readTable('dr2.txt');
% note: src is structure containing the DR2 fields, e.g.
% src.source_id = 207628584632757632
% src.parallax = 0.271745260505027

% (edited) table from GOST (https://gaia.esac.esa.int/gost):
table = readTable('gost.txt'); % this reads the table to structure table
% note: table is a structure with the following fields: 
%                        colNames: {10×1 cell}
%                            file: 'gost.txt'
%                           types: [10×1 double]
%                            nRow: 26
%                              ra: [26×1 double]
%                             dec: [26×1 double]
%                          CcdRow: [26×1 double]
%                  zetaFieldAngle: [26×1 double]
%                       scanAngle: [26×1 double]
%         parallaxFactorAlongScan: [26×1 double]
%        parallaxFactorAcrossScan: [26×1 double]
%     ObservationTimeAtBarycentre: [26×1 double]

nTr = table.nRow; % number of tranits (predicted from GOST)
raRad = src.ra * pi / 180;
decRad = src.dec * pi / 180;

% scan geometry etc (these are vectors of length nTr):
s = sin(table.scanAngle);
c = cos(table.scanAngle);
pf = table.parallaxFactorAlongScan;
t = 2000.0 + (table.ObservationTimeAtBarycentre - JD2000) / year;
tau = t - tRef;
tau_recedingNode = t_recedingNode - tRef;

% multiply by 9 CCD strips:
s = [s; s; s; s; s; s; s; s; s];
c = [c; c; c; c; c; c; c; c; c];
pf = [pf; pf; pf; pf; pf; pf; pf; pf; pf];
tau = [tau; tau; tau; tau; tau; tau; tau; tau; tau];
nTr = length(s);

% design matrix (nTr rows, 5 columns for ra dec, plx, pmra, pmdec):
D = [ s, c, pf, s.*tau, c.*tau ];

sig0 = [src.ra_error; src.dec_error; src.parallax_error; ...
    src.pmra_error; src.pmdec_error];
sig0 = sig0 / mean(sig0);

corr0 = [src.ra_dec_corr; src.ra_parallax_corr; src.ra_pmra_corr; ...
    src.ra_pmdec_corr; src.dec_parallax_corr; src.dec_pmra_corr; ...
    src.dec_pmdec_corr; src.parallax_pmra_corr; src.parallax_pmdec_corr; ...
    src.pmra_pmdec_corr];

% Monte Carlo: generate nMC random orbits at each true parallax plx0:
M0 = ones(nMC,1) * M0_fixed;

frac0 = zeros(np,ns); % results for plx < plxObs
frac1 = zeros(np,ns); % results for plx < plxObs & uwe < uweMax

tic
for is = 1 : ns
    uwe = zeros(nMC,1); % array to hold the UWE (including photon noise)
    plx = zeros(nMC,1); % array to hold the observed (biased, noisy) parallax
    cosiLim = [-1,1] * sqrt(1 - siniMin(is)^2); % limits for cos(i)
    
    for ip = 1 : np
        
        plx0 = plxList(ip); % true parallax
        
        % cos(i) is uniform in [cosiLim(1), cosiLim(2)]:
        cosi = cosiLim(1) + rand(nMC,1)*(cosiLim(2)-cosiLim(1));
        sini = sqrt(1 - cosi.^2);
        a = 0.341 * plx0 ./ sini; % true orbital semi-diameter
        
        omega = 0; % periastron is at the receding node
        Omega = twopi * rand(nMC,1); % Omega is uniform in [0,2*pi]
        
        % Thiele-Innes constants (these are vectors of length nMC):
        A = a .* (cos(omega).*cos(Omega) - sin(omega).*sin(Omega).*cosi);
        B = a .* (cos(omega).*sin(Omega) + sin(omega).*cos(Omega).*cosi);
        F = a .* (-sin(omega).*cos(Omega) - cos(omega).*sin(Omega).*cosi);
        G = a .* (-sin(omega).*sin(Omega) + cos(omega).*cos(Omega).*cosi);
        
        % calculate UWE:
        for k = 1 : nMC
            % remove 21 observations randomly
            q = randperm(nTr, src.astrometric_n_good_obs_al);
            dof = length(q) - 5;
            M = M0(k) + (twopi/P) * tau(q);  % mean anomaly
            x = A(k) * cos(M) + F(k) * sin(M);  % displacement in RA
            y = B(k) * cos(M) + G(k) * sin(M);  % displacement in Dec
            d0 = x.*s(q) + y.*c(q); % noiseless obs
            d1 = d0 + randn(size(d0)) * sigma_obs; % noisy obs
            sol = D(q,:) \ d1; % LS solution of D * sol = d1
            res = (d1 - D(q,:) * sol) / sigma_obs;
            uwe(k) = sqrt(res'*res / dof);
            plx(k) = plx0 + sol(3);
        end
        plx = plx + randn(nMC,1) * sigma_sys; % add systematic uncertainty
        frac0(ip,is) = length(find(plx < plxObs)) / nMC;
        frac1(ip,is) = length(find(plx < plxObs & uwe < uweMax)) / nMC;
        
        % for the impatient:
        pc = 100 * ((is-1)*np+ip)/(ns*np);
        fprintf('is = %d(%d), ip = %d(%d) done = %4.1f%%; time elapsed = %f s\n', ...
            is, ns, ip, np, pc, toc);
    end
end

% output tables of the results

% fraction of cases with plx < plxObs for different limits of sin(i)
fid = fopen('simFrac0VsTruePlx.txt','w');
fprintf(fid,'plxTrue,frac0_0,frac0_2,frac0_4,frac0_6,frac0_8\n');
for ip = 1 : np
    fprintf(fid,'%f,%f,%f,%f,%f,%f\n', plxList(ip), frac0(ip,:));
end
fclose(fid);

% fraction of cases with plx < plxObs and uwe < uweMax
fid = fopen('simFrac1VsTruePlx.txt','w');
fprintf(fid,'plxTrue,frac0_0,frac0_2,frac0_4,frac0_6,frac0_8\n');
for ip = 1 : np
    fprintf(fid,'%f,%f,%f,%f,%f,%f\n', plxList(ip), frac1(ip,:));
end
fclose(fid);
