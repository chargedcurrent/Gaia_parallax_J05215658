% Main program to analyse the sensitivity of the Gaia DR2 parallax and 
% proper motion estimates for J05215658 (Gaia DR2 207628584632757632) 
% to orbital motion

% The calculations are made for an assumed orbit size of 1 mas,
% since the biases scale linearly with the orbit size  

% V1 (2018-09-06): random circular orbit with fixed period
% V2 (2018-10-14): phase in orbit fixed by RV analysis
% V3 (2018-11-07): calculates also bias in pm (RA, Dec, l, b, total)

% L. Lindegren (Lund Observatory) 2018-09-06, 2018-10-14, 2018-11-07

clear all
clc

% random number initialization for reproducibility:
seed = 1;
RandStream.setGlobalStream(RandStream('mt19937ar','Seed',1));

% general constants:
twopi = 2 * pi;
JD2000 = 2451545.0; % JD for J2000.0
tRef = 2015.5; % reference epoch for Gaia DR2
year = 365.25; % Julian year in days

% assumed period and orbital radius of the binary:
P = 83.205 / year; % [years]
a = 1.0; % [mas]
orbRatio = 0.34; % ratio of binary angular motion to parallax is 0.34/sin(i)

% assumed sigma per CCD observation:
sigma_obs = 0.28; % [mas]

% number of Monte Carlo experiments (number of random orbits):
nMC = 10000;

% time of maximum blueshift (e-mail Thompson 2018-10-13 kl. 15:35): 
t_recedingNode = 2000.0 + (2458110.0 - JD2000) / year;

% load Gaia DR2 data for J05215658 from Gaia Archive:
src = readTable('dr2.txt');
% note: src is structure containing the DR2 fields, e.g.
% src.source_id = 207628584632757632
% src.parallax = 0.271745260505027

% (edited) table from GOST (https://gaia.esac.esa.int/gost):
table = readTable('gost.txt'); % this reads the table to structure table
% note: table is a structure with the following fields: 
%                        colNames: {10×1 cell}
%                            nCol: 10
%                            file: 'gost.txt'
%                           types: [10×1 double]
%                            nRow: 26
%                              ra: [26×1 double]
%                             dec: [26×1 double]
%                          CcdRow: [26×1 double]
%                  zetaFieldAngle: [26×1 double]
%                       scanAngle: [26×1 double]
%         parallaxFactorAlongScan: [26×1 double]
%        parallaxFactorAcrossScan: [26×1 double]
%     ObservationTimeAtBarycentre: [26×1 double]

nTr = table.nRow; % number of tranits (predicted from GOST)
raRad = src.ra * pi / 180;
decRad = src.dec * pi / 180;

% scan geometry etc (these are vectors of length nTr):
s = sin(table.scanAngle);
c = cos(table.scanAngle);
pf = table.parallaxFactorAlongScan;
t = 2000.0 + (table.ObservationTimeAtBarycentre - JD2000) / year;
tau = t - tRef;
tau_recedingNode = t_recedingNode - tRef;

% multiply by 9 CCD strips (same time and geometry assumed for all CCDs):
s = [s; s; s; s; s; s; s; s; s];
c = [c; c; c; c; c; c; c; c; c];
pf = [pf; pf; pf; pf; pf; pf; pf; pf; pf];
tau = [tau; tau; tau; tau; tau; tau; tau; tau; tau];
nTr = length(s);

% design matrix (nTr rows, 5 columns for ra dec, plx, pmra, pmdec):
D = [ s, c, pf, s.*tau, c.*tau ];

% relative sigmas per observation:
sig0 = [src.ra_error; src.dec_error; src.parallax_error; ...
    src.pmra_error; src.pmdec_error];
sig0 = sig0 / mean(sig0);

corr0 = [src.ra_dec_corr; src.ra_parallax_corr; src.ra_pmra_corr; ...
    src.ra_pmdec_corr; src.dec_parallax_corr; src.dec_pmra_corr; ...
    src.dec_pmdec_corr; src.parallax_pmra_corr; src.parallax_pmdec_corr; ...
    src.pmra_pmdec_corr];

%--------------------------------------------------------------------------
% Monte Carlo: generate nMC random orbits
M0 = ones(nMC,1) * 4.01982647514223; % mean anomaly (+omega) at 2015.5
cosi = 2 * rand(nMC,1) - 1; % cos(i) is uniform in [-1,1]
omega = 0; % periastron is at the receding node
Omega = twopi * rand(nMC,1); % Omega is uniform in [0,2*pi]

% Thiele-Innes constants (these are vectors of length nMC):
A = a * (cos(omega).*cos(Omega) - sin(omega).*sin(Omega).*cosi);
B = a * (cos(omega).*sin(Omega) + sin(omega).*cos(Omega).*cosi);
F = a * (-sin(omega).*cos(Omega) - cos(omega).*sin(Omega).*cosi);
G = a * (-sin(omega).*sin(Omega) + cos(omega).*cos(Omega).*cosi);

% calculate parallax biases:
plxBias = zeros(nMC,1); % array to hold biases
pmaBias = zeros(nMC,1); % array to hold biases
pmdBias = zeros(nMC,1); % array to hold biases
rmsRes0 = zeros(nMC,1); % array to hold the RMS residuals of noiseless obs
rmsRes1 = zeros(nMC,1); % array to hold the RMS residuals of noisy obs
for k = 1 : nMC
    % removed 21 observations randomly
    q = randperm(nTr, src.astrometric_n_good_obs_al);
    dof = length(q) - 5;
    M = M0(k) + (twopi/P) * tau(q);  % mean anomaly
    x = A(k) * cos(M) + F(k) * sin(M);  % displacement in RA
    y = B(k) * cos(M) + G(k) * sin(M);  % displacement in Dec
    d0 = x.*s(q) + y.*c(q); % noiseless obs
    d1 = d0 + randn(size(d0)) * sigma_obs; % noisy obs
    sol = D(q,:) \ [d0,d1]; % LS solution of D * sol = d
    plxBias(k) = sol(3,1); % plx is the third unknown in D
    pmaBias(k) = sol(4,1); % plx is the third unknown in D
    pmdBias(k) = sol(5,1); % plx is the third unknown in D
    res0 = d0 - D(q,:) * sol(:,1);
    res1 = d1 - D(q,:) * sol(:,2);
    rmsRes0(k) = sqrt(res0'*res0 / dof);
    rmsRes1(k) = sqrt(res1'*res1 / dof);
end

% plot bias versus cos(i):
figure(1)
plot(cosi, plxBias, '.');
xlabel('cos i');
ylabel('Parallax bias for assumed orbital radius');
grid on;

% plot RMS residual versus cos(i):
figure(2)
plot(cosi, rmsRes0, '.');
xlabel('cos i');
ylabel('RMS residual for assumed orbital radius');
grid on;

% plot bias versus RMS residual:
figure(3)
plot(rmsRes0, plxBias, '.');
xlabel('RMS residual for assumed orbital radius');
ylabel('Parallax bias for assumed orbital radius');
grid on;

figure(4)
hist(rmsRes1/sigma_obs,100)
xlabel('UWE for observational uncertainty 0.28 mas (213 observations)');
ylabel('Number of cases');
title(sprintf('Assumed orbital radius %g mas', a));
grid on;

figure(5)
hist(plxBias,100)
xlabel('Parallax bias [mas]');
ylabel('Number of cases');
title(sprintf('Assumed orbital radius %g mas', a));
grid on;

figure(6)
plot(pmaBias, pmdBias, '.')
xlabel('Bias in pmra [mas/yr]');
ylabel('Bias in pmdec [mas/yr]');
title(sprintf('Assumed orbital radius %g mas', a));
grid on;

figure(7)
sini = sqrt(1 - cosi.^2);
biasOverPlx = orbRatio * plxBias ./ sini;
plot(sini, biasOverPlx, '.')
xlabel('sin i');
ylabel('Ratio of parallax bias to \pi');
grid on;

fid = fopen('simPlxPmBiasRes_RV.txt','w');
fprintf(fid,'iMC, cosI, sinI, plxBias0, biasOverPlx, rmsRes0, pmRaBias, pmDecBias, pmLonBias, pmLatBias, pmTotBias\n');
for k = 1 : nMC
    [ lRad, bRad, ml, mb ] = equ2galPm( raRad, decRad, pmaBias(k), pmdBias(k) );
    fprintf(fid,'%d, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f\n', ...
        k, cosi(k), sini(k), plxBias(k), biasOverPlx(k), ...
        rmsRes0(k), pmaBias(k), pmdBias(k), ml, mb, sqrt(ml^2+mb^2));
end
fclose(fid);
